import { loadEnv } from '@/config';

loadEnv();
