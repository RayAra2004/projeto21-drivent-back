-- AlterTable
ALTER TABLE "Address" ALTER COLUMN "addressDetail" DROP NOT NULL;
